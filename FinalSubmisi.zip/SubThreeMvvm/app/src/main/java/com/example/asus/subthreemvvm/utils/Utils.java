package com.example.asus.subthreemvvm.utils;

public class Utils {
    public final static String DATE_FORMAT = "dd MMMM yyyy";
    public final static String DATE_FORMAT_DAY = "EEEE, MMM d, yyyy";
}
